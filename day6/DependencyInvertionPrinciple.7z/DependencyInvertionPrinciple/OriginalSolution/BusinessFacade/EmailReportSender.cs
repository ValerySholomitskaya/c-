﻿using System;

namespace OriginalSolution.BusinessFacade
{
    public class EmailReportSender
    {
        public EmailReportSender()
        {
            Console.WriteLine("Create EmailReportSender");
        }

        public string SmtpServer { get; set; }

        public void Send(Report report)
        {
            if (!string.IsNullOrEmpty(SmtpServer))
            {
                Console.WriteLine("Send '{0}' to '{1}' by means of email", report.Name, SmtpServer);
            }
            else
            {
                Console.WriteLine("Send '{0}' by means of email", report.Name);
            }
        }
    }
}
