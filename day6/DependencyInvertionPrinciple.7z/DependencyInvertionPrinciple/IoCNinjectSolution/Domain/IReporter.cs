﻿namespace IoCNinjectSolution.Domain
{
    public interface IReporter
    {
        void SendReports();
    }
}
