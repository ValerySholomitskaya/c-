﻿namespace IoCSolution.Domain
{
    public interface IReporter
    {
        void SendReports();
    }
}
